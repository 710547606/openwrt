# Instructions / 使用说明

Please refer to the relevant instructions in the [user manual](../documents) for customizing OpenWrt.

OpenWrt 的个性化定制方法，请参考 [使用文档](../documents/README.cn.md) 中的相关说明。

